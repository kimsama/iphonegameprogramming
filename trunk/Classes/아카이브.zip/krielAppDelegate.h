//
//  krielAppDelegate.h
//  kriel
//
//  Created by Hyoun Woo Kim on 09. 06. 17.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cocos2d.h"
#import "MenuScene.h"

@interface krielAppDelegate : NSObject <UIApplicationDelegate> {
    
}

@end

