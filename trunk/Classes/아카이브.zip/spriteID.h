//
//  spriteID.h
//  kriel
//
//  Created by Hyoun Woo Kim on 09. 10. 24.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface spriteID : NSObject {
	NSDictionary *resourceID;

}

@property (copy, readwrite) NSDictionary *resourceID;

@end
